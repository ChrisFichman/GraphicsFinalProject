//wings.h
//wings for crafts

#include "CSCIx229.h"

//Wings in attack position

