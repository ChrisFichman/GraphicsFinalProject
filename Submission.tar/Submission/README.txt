README.txt

Compile and run instructions
>make
>./finalChrisFichman
>make clean

ESC key to exit

Directions for using the program are available by pressing i

Additional notes:
There is not as much work done as I had hoped, due to the fact that
I saw fit to completely reorganize my program for easier understanding.
There are now 3 header files with data structures and helper functions, 
such as Vector, Print, Sphere, and Cube. I chose this layout, because it
will be much more conducive for when I get working on collisions, as we
approach the end of the class. I also had to re-code the x-wing from 
scratch, with lighting. I will have another submission on sunday with 
more of my tasks done.


try typing: >make me_a_sandwich

